# Demo video narration (target: 2–3 minutes)

**Opening:** "Hello, this is FraudShield AI, a digital-payment safety companion. It helps users spot warning signs in suspicious SMS, WhatsApp messages and payment requests before they act."

**Problem:** "Scams can use urgent threats, fake rewards, KYC pressure, suspicious links or requests for secret credentials. People need simple explanations and safe next steps."

**Live demo:** "I select this sample claiming a cashback reward and asking for a UPI PIN through a shortened link. I click Analyse. FraudShield shows its indicator score, risk band and matched warning signs. The explanation reminds the user not to share a UPI PIN and to verify through the official app."

"Now I test an ordinary bill notification. Fewer known warning patterns are detected. But a low score is not a guarantee that a message is genuine."

**How it works:** "Python pattern checks create an explainable indicator score. If a Gemini API key is configured, Gemini adds a plain-language explanation. Local checks still work without the API."

**Closing:** "FraudShield does not connect to bank accounts, initiate payments or verify transactions. It encourages users to pause and independently verify unexpected requests. Thank you."

## Recording checklist
Run the app and record the actual browser window. Show both sample analyses. Keep the video under five minutes. Upload as Public or Unlisted, never Private. Do not show API keys, private messages or real account details.
